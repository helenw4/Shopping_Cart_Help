# Shopping Cart Functionality

I have created a shopping cart that displays my understanding of the core functionality used for a storefront application, specifically a clothing store offering shirts, hats and gloves. This has allowed me to practice my undertanding of JavaScript to further development in my career. 

Please keep in mind that this project will be update the more practice and skills I obtain on my coding journey. 



